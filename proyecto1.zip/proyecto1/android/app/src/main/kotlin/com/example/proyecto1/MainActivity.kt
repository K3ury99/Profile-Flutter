package com.example.proyecto1

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
